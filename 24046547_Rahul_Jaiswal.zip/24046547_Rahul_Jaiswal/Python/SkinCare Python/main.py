# main.py - The main program file
from read import read_products_from_file
from operations import calculate_selling_price, apply_discount_policy
from write import generate_invoice, update_stock_file
import datetime

def display_menu():
    """Display the main menu options"""
    print("\nWeCare Skin Care Product System")
    print("=" * 40)
    print("1. View All Products")
    print("2. Make a Sale")
    print("3. Restock Products")
    print("4. Exit")
    print("=" * 40)

def display_products(products):
    """Display all products in a table format"""
    print("\nAvailable Products:")
    print("=" * 85)
    print(f"{'No.':<5}{'Product Name':<20}{'Brand':<15}{'Qty':<5}{'Price (Rs)':<12}{'Country':<15}")
    print("-" * 85)
    
    for idx, product in enumerate(products, 1):
        selling_price = calculate_selling_price(product['cost_price'])
        print(f"{idx:<5}{product['name']:<20}{product['brand']:<15}"
              f"{product['quantity']:<5}{selling_price:<12.2f}{product['country']:<15}")
    print("=" * 85)

def make_sale(products):
    """Handle the sales transaction process"""
    display_products(products)
    
    customer_name = input("\nEnter customer name: ")
    items = []
    total = 0
    
    while True:
        try:
            product_num = int(input("Enter product number (0 to finish): "))
            if product_num == 0:
                break
            if product_num < 1 or product_num > len(products):
                print("Invalid product number. Please try again.")
                continue
                
            quantity = int(input("Enter quantity: "))
            product = products[product_num - 1]
            
            if quantity > product['quantity']:
                print(f"Not enough stock! Only {product['quantity']} available.")
                continue
                
            # Apply buy 3 get 1 free policy
            free_items, payable_quantity = apply_discount_policy(quantity)
            selling_price = calculate_selling_price(product['cost_price'])
            item_total = payable_quantity * selling_price
            
            items.append({
                'name': product['name'],
                'brand': product['brand'],
                'quantity': quantity,
                'free_items': free_items,
                'price': selling_price,
                'total': item_total
            })
            
            total += item_total
            # Update stock in memory
            product['quantity'] -= (quantity + free_items)
            
            print(f"Added {quantity} {product['name']} (Get {free_items} free)")
            
        except ValueError:
            print("Invalid input. Please enter numbers only.")
    
    if items:
        # Generate invoice
        generate_invoice(customer_name, items, total, "sale")
        # Update the stock file
        update_stock_file(products)
        print("\nSale completed successfully!")
        print(f"Total amount: Rs. {total:.2f}")
    else:
        print("No items were purchased.")

def restock_products(products):
    """Handle product restocking"""
    display_products(products)
    
    vendor_name = input("\nEnter vendor/supplier name: ")
    items = []
    total_cost = 0
    
    while True:
        try:
            product_num = int(input("Enter product number to restock (0 to finish): "))
            if product_num == 0:
                break
            if product_num < 1 or product_num > len(products):
                print("Invalid product number. Please try again.")
                continue
                
            quantity = int(input("Enter restock quantity: "))
            new_price = float(input("Enter new cost price (or 0 to keep current): "))
            
            product = products[product_num - 1]
            
            if new_price > 0:
                product['cost_price'] = new_price
                
            product['quantity'] += quantity
            item_cost = quantity * product['cost_price']
            
            items.append({
                'name': product['name'],
                'brand': product['brand'],
                'quantity': quantity,
                'price': product['cost_price'],
                'total': item_cost
            })
            
            total_cost += item_cost
            print(f"Added {quantity} {product['name']} to stock")
            
        except ValueError:
            print("Invalid input. Please enter numbers only.")
    
    if items:
        # Generate restock invoice
        generate_invoice(vendor_name, items, total_cost, "restock")
        # Update the stock file
        update_stock_file(products)
        print("\nRestocking completed successfully!")
        print(f"Total cost: Rs. {total_cost:.2f}")
    else:
        print("No items were restocked.")

def main():
    """Main program function"""
    product_file = "products.txt"
    products = read_products_from_file(product_file)
    
    while True:
        display_menu()
        choice = input("Enter your choice (1-4): ")
        
        if choice == '1':
            display_products(products)
        elif choice == '2':
            make_sale(products)
        elif choice == '3':
            restock_products(products)
        elif choice == '4':
            print("Thank you for using WeCare System. Goodbye!")
            break
        else:
            print("Invalid choice. Please enter 1-4.")

if __name__ == "__main__":
    main()
