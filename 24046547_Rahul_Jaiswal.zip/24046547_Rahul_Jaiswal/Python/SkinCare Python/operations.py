# operations.py - Contains business logic and calculations

def calculate_selling_price(cost_price):
    """Calculate selling price with 200% markup"""
    return cost_price * 2

def apply_discount_policy(quantity):
    """
    Apply 'buy 3 get 1 free' policy
    Returns tuple of (free_items, payable_quantity)
    """
    free_items = quantity // 3
    payable_quantity = quantity - free_items
    return (free_items, payable_quantity)
