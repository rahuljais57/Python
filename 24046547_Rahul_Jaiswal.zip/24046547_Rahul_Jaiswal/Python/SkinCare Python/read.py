# read.py - Handles reading product data from files

def read_products_from_file(filename):
    """
    Read product data from a text file and return as a list of dictionaries
    Each product has: name, brand, quantity, cost_price, country
    """
    products = []
    try:
        with open(filename, 'r') as file:
            for line in file:
                # Skip empty lines
                if not line.strip():
                    continue
                    
                parts = [part.strip() for part in line.strip().split(',')]
                
                if len(parts) == 5:
                    try:
                        product = {
                            'name': parts[0],
                            'brand': parts[1],
                            'quantity': int(parts[2]),
                            'cost_price': float(parts[3]),
                            'country': parts[4]
                        }
                        products.append(product)
                    except ValueError:
                        print(f"Warning: Could not parse line: {line}")
    except FileNotFoundError:
        print(f"Error: File '{filename}' not found. Starting with empty product list.")
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")
    
    return products
