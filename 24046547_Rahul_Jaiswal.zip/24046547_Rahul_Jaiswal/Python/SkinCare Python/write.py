# write.py - Handles writing invoices and updating stock file
import datetime

def generate_invoice(name, items, total_amount, invoice_type):
    """
    Generate an invoice file for sales or restocking
    invoice_type can be 'sale' or 'restock'
    """
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{invoice_type}_invoice_{timestamp}.txt"
    
    with open(filename, 'w') as file:
        file.write("=" * 50 + "\n")
        if invoice_type == "sale":
            file.write("WE CARE - SALES INVOICE\n")
            file.write(f"Customer: {name}\n")
        else:
            file.write("WE CARE - RESTOCK INVOICE\n")
            file.write(f"Vendor: {name}\n")
        
        file.write(f"Date: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        file.write("=" * 50 + "\n\n")
        
        if invoice_type == "sale":
            file.write(f"{'Product':<20}{'Brand':<15}{'Qty':<5}{'Free':<5}{'Price':<10}{'Total':<10}\n")
            file.write("-" * 65 + "\n")
            for item in items:
                file.write(f"{item['name']:<20}{item['brand']:<15}{item['quantity']:<5}{item['free_items']:<5}"
                          f"{item['price']:<10.2f}{item['total']:<10.2f}\n")
        else:
            file.write(f"{'Product':<20}{'Brand':<15}{'Qty':<5}{'Cost':<10}{'Total':<10}\n")
            file.write("-" * 50 + "\n")
            for item in items:
                file.write(f"{item['name']:<20}{item['brand']:<15}{item['quantity']:<5}"
                          f"{item['price']:<10.2f}{item['total']:<10.2f}\n")
        
        file.write("\n" + "=" * 25 + "\n")
        if invoice_type == "sale":
            file.write(f"TOTAL AMOUNT: Rs. {total_amount:.2f}\n")
        else:
            file.write(f"TOTAL COST: Rs. {total_amount:.2f}\n")
        file.write("=" * 25 + "\n")
    
    print(f"Invoice generated: {filename}")

def update_stock_file(products, filename="products.txt"):
    """Update the product stock file with current quantities"""
    try:
        with open(filename, 'w') as file:
            for product in products:
                file.write(f"{product['name']}, {product['brand']}, {product['quantity']}, "
                          f"{product['cost_price']}, {product['country']}\n")
        print("Product stock file updated successfully.")
    except Exception as e:
        print(f"Error updating stock file: {e}")
